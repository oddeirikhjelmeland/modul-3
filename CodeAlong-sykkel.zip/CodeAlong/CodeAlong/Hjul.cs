﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeAlong
{
    internal class Hjul
    {
        public int AntallEiker = 30;
        public int  dimensjon = 20;

    }
}

